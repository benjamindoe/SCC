﻿$(function () {
    $('select').material_select();
});