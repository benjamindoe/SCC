﻿External Resources Used:
Google Material Design Icons, Apache Licence https://github.com/google/material-design-icons/
Materialize CSS based on Google's Material Design Language, MIT Licence http://materializecss.com/
RESTful JSON Currency Converter API http://fixer.io/
Clearbit RESTful logo API https://clearbit.com/logo/
Google Map APIs (Web and HTTP) https://developers.google.com/maps/
OpenWeatherMap, Inc. http://openweathermap.org